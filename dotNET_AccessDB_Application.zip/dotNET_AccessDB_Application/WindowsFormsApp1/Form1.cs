﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        static string conString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\dotNET_Project\dotNET_Assignment_6.accdb";
        OleDbConnection connection = new OleDbConnection(conString);
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
            //DataGridView Properties
            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].Name = "Client ID";
            dataGridView1.Columns[1].Name = "Client Name";
            dataGridView1.Columns[2].Name = "Date of Birth";
            dataGridView1.Columns[3].Name = "Client Address";

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //Selection Mode
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;

        }

        //Insert into DB
        private void add(string name, DateTime dob, string address)
        {
            //SQL statement
            string sql = "INSERT INTO Clients(Client_Name, Client_DOB, Client_Address) VALUES(@name, @dob, @address)";
            cmd = new OleDbCommand(sql, connection);

            //Add Parameters
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@dob", dob);
            cmd.Parameters.AddWithValue("@address", address);

            try
            {
                connection.Open();
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Record inserted successfully.");
                }
                clearTextBoxes();
                connection.Close();
            } catch (Exception ex)
            {
                MessageBox.Show("Error has occurred: " + ex);
                connection.Close();
            }
        }


        //Fill DataGridView
        private void populate(string id, string name, DateTime dob, string address)
        {
            dataGridView1.Rows.Add(id, name, dob, address);
        }

        //Retrieve from DB
        private void retrieve()
        {
            dataGridView1.Rows.Clear();
            //SQL statement
            String sql = "SELECT * FROM Clients";
            cmd = new OleDbCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new OleDbDataAdapter(cmd);

                adapter.Fill(dt);

                //Loop through contents of dt
                foreach (DataRow row in dt.Rows)
                {
                    populate(row[0].ToString(), row[1].ToString(), Convert.ToDateTime(row[2].ToString()), row[3].ToString());
                }
                clearTextBoxes();
                connection.Close();
                //Clear DT 
                dt.Rows.Clear();
            } catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
                connection.Close();
            }

        }

        //Update DB
        private void update(int id, string name, DateTime dob, string address)
        {
            //SQL statement
            string sql = "Update Clients SET Client_Name='" + name + "', Client_DOB=" + dob.ToShortDateString() + ",Client_Address='" + address + "' WHERE Client_ID=" + id;
            cmd = new OleDbCommand(sql, connection);

            //Open connection, update, retrieve, dataGridView
            try
            {
                connection.Open();
                adapter = new OleDbDataAdapter(cmd);

                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                {
                    clearTextBoxes();
                    MessageBox.Show("Successfully updated row.");
                }
                clearTextBoxes();
                connection.Close();

                //Refresh
                retrieve();
            }catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex);
            }
        }

        //Delete from DB
        private void delete(int id)
        {
            //SQL statement
            string sql = "DELETE FROM Clients WHERE Client_ID = " + id + "";
            cmd = new OleDbCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new OleDbDataAdapter(cmd);

                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                //Prompt for confirmation
                if(MessageBox.Show("Are you sure?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        clearTextBoxes();
                        MessageBox.Show("Row has been successfuly deleted.");
                    }
                }

                connection.Close();
                retrieve();
            } catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex);
                connection.Close();
            }
        }

        //Clear text boxes
        private void clearTextBoxes()
        {
            textBox1.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            add(textBox1.Text, dateTimePicker1.Value, textBox2.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            retrieve();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            int id = Convert.ToInt32(selected);

            update(id, textBox1.Text, dateTimePicker1.Value, textBox2.Text);
        }

        private void button4_Click(object sender, EventArgs e) {
            string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            int id = Convert.ToInt32(selected);
            delete(id);
            
        }
        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            clearTextBoxes();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
