# dotNET
A repository for projects developed with the dotNET framework
